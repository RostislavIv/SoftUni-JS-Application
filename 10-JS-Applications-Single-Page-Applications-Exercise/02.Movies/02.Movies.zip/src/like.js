import { showHome } from "./home.js";
import { requestEditMovie } from "./requestData.js";

export async function onLike(movie) {
  // TODO
  showHome();
}
