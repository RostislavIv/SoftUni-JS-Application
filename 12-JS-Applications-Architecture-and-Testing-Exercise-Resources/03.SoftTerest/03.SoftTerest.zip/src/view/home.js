const homeDiv = document.getElementById("homePage");

export function homePage(showSection) {
  showSection(homeDiv);
}
